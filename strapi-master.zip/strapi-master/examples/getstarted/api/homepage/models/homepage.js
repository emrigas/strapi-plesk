'use strict';

/**
 * Lifecycle callbacks for the `homepage` model.
 */

module.exports = {};
