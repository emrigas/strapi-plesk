'use strict';

/**
 * Lifecycle callbacks for the `Address` model.
 */

module.exports = {};
