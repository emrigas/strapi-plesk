module.exports = {
  type: {
    Restaurant: {
      _description: 'This is the restaurant desc',
    },
  },
};
