'use strict';

/**
 * Lifecycle callbacks for the `Menusection` model.
 */

module.exports = {};
