'use strict';

/**
 * Lifecycle callbacks for the `Menu` model.
 */

module.exports = {};
