'use strict';

/**
 * Lifecycle callbacks for the `Review` model.
 */

module.exports = {};
