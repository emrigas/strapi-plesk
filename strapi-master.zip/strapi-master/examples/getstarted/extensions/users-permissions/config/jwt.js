module.exports = {
  jwtSecret: process.env.JWT_SECRET || 'c98f7e9c-dc1d-4ee1-a380-53c3a7125a7e',
};
