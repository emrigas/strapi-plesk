module.exports = (ctx, next) => {
  next();
};
