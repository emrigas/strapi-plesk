module.exports = {
  customRoute(ctx) {
    ctx.body = 'allRight';
  },
};
